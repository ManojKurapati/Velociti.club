[Founder photos from the Velociti photo shoot go here.]
